<?php
require_once 'includes/header.php';
require_once 'includes/slider.php';
require_once 'includes/news-notice.php';
require_once 'includes/service.php';
require_once 'includes/right-sidebar.php';
require_once 'includes/footer.php';
?>